
from setuptools import setup
  
setup(
    name='dq_dimensions',
    version='0.1',
    description='',
    author='PetroLink',
    author_email='allan.gonzalez@colostate.edu',
    packages=['dq_dimensions'],
    install_requires=[
        'datetime',
        'typing',
        'copy',
    ],
)